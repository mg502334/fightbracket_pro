import React, { useState, useCallback } from "react";
import { Toaster, toast } from "sonner";
import { motion, AnimatePresence } from "motion/react";
import {
  Trophy, GitBranch, UserCheck, Monitor, MessageSquare, Smartphone,
  ExternalLink, RefreshCw, Zap, MapPin, Globe,
} from "lucide-react";

import { GameBanner } from "./components/GameBanner";
import { BracketView } from "./components/BracketView";
import { CheckInPanel } from "./components/CheckInPanel";
import { StationsPanel } from "./components/StationsPanel";
import { SMSPanel } from "./components/SMSPanel";
import { AnnouncementOverlay } from "./components/AnnouncementOverlay";
import { MobileCompanion } from "./components/MobileCompanion";

import {
  GAME_THEMES, PLAYERS, INITIAL_BRACKETS, STATIONS, TOURNAMENT,
  type BracketMatch, type Player, type Station, type SMSLog, type GameTheme,
} from "./data/tournamentData";

type Tab = 'overview' | 'bracket' | 'checkin' | 'stations' | 'sms' | 'mobile';
type GameId = 'tekken8' | 'sf6' | 'fatalFury';

const GAME_ORDER: GameId[] = ['tekken8', 'sf6', 'fatalFury'];
const TABS: { id: Tab; label: string; icon: React.ComponentType<{ size?: number }> }[] = [
  { id: 'overview', label: 'OVERVIEW', icon: Trophy },
  { id: 'bracket', label: 'BRACKET', icon: GitBranch },
  { id: 'checkin', label: 'CHECK-IN', icon: UserCheck },
  { id: 'stations', label: 'STATIONS', icon: Monitor },
  { id: 'sms', label: 'SMS', icon: MessageSquare },
  { id: 'mobile', label: 'MOBILE', icon: Smartphone },
];

export default function App() {
  const [activeGame, setActiveGame] = useState<GameId>('tekken8');
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [players, setPlayers] = useState<Player[]>(PLAYERS);
  const [matches, setMatches] = useState<BracketMatch[]>(INITIAL_BRACKETS);
  const [stations, setStations] = useState<Station[]>(STATIONS);
  const [smsLogs, setSmsLogs] = useState<SMSLog[]>([]);
  const [announcement, setAnnouncement] = useState<BracketMatch | null>(null);
  const [syncing, setSyncing] = useState(false);

  const theme: GameTheme = GAME_THEMES[activeGame];
  const gamePlayers = players.filter(p => p.gameId === activeGame);
  const gameMatches = matches.filter(m => m.gameId === activeGame);
  const activeMatches = gameMatches.filter(m => m.state === 'in_progress' || m.state === 'called');
  const checkedInCount = gamePlayers.filter(p => p.checkedIn).length;

  const handleCheckIn = useCallback((playerId: string, checked: boolean) => {
    setPlayers(prev => prev.map(p => p.id === playerId ? { ...p, checkedIn: checked } : p));
    const player = PLAYERS.find(p => p.id === playerId);
    toast(checked ? `${player?.tag} checked in` : `${player?.tag} checked out`, {
      style: { background: '#0A1428', border: `1px solid ${checked ? '#00FF88' : '#FF1744'}40`, color: '#E8F4F8' },
    });
  }, []);

  const handleCallMatch = useCallback((match: BracketMatch, stationId?: number) => {
    const sid = stationId ?? match.stationId;
    if (!sid) return;

    setMatches(prev => prev.map(m => m.id === match.id ? { ...m, state: 'called', stationId: sid } : m));
    const updatedMatch: BracketMatch = { ...match, state: 'called', stationId: sid };
    setAnnouncement(updatedMatch);

    const playerIds = [match.player1Id, match.player2Id].filter(Boolean) as string[];
    const gameThemeName = GAME_THEMES[match.gameId].displayName;

    playerIds.forEach((pid, idx) => {
      const player = PLAYERS.find(p => p.id === pid);
      if (!player) return;
      setSmsLogs(prev => [...prev, {
        id: `sms-${Date.now()}-${idx}`,
        playerId: pid,
        message: `[${gameThemeName}] ${player.tag}, your ${match.roundName} match has been called! Report to Station ${sid} immediately. — CLASH OF KINGS VII`,
        sentAt: new Date(),
        status: Math.random() > 0.1 ? 'delivered' : 'sent',
        matchId: match.id,
      }]);
    });

    setPlayers(prev => prev.map(p => playerIds.includes(p.id) ? { ...p, smsNotified: true } : p));
    toast.success(`Match called — Station ${sid}`, {
      style: { background: '#0A1428', border: `1px solid ${theme.primaryColor}40`, color: '#E8F4F8' },
    });
  }, [theme.primaryColor]);

  const handleAssignMatch = useCallback((stationId: number, matchId: string) => {
    setStations(prev => prev.map(s => s.id === stationId ? { ...s, matchId } : s));
    setMatches(prev => prev.map(m => m.id === matchId ? { ...m, stationId } : m));
    toast(`Match assigned to Station ${stationId}`, {
      style: { background: '#0A1428', border: `1px solid ${theme.primaryColor}30`, color: '#E8F4F8' },
    });
  }, [theme.primaryColor]);

  const handleClearStation = useCallback((stationId: number) => {
    setStations(prev => {
      const station = prev.find(s => s.id === stationId);
      if (station?.matchId) {
        setMatches(pm => pm.map(m => m.id === station.matchId ? { ...m, stationId: null } : m));
      }
      return prev.map(s => s.id === stationId ? { ...s, matchId: null } : s);
    });
  }, []);

  const handleSendSMS = useCallback((playerIds: string[], message: string, matchId?: string) => {
    const newLogs = playerIds.map((pid, i): SMSLog => ({
      id: `sms-${Date.now()}-${i}`,
      playerId: pid,
      message,
      sentAt: new Date(),
      status: Math.random() > 0.08 ? 'delivered' : 'sent',
      matchId,
    }));
    setSmsLogs(prev => [...prev, ...newLogs]);
    toast.success(`SMS sent to ${playerIds.length} player${playerIds.length !== 1 ? 's' : ''}`, {
      style: { background: '#0A1428', border: `1px solid ${theme.primaryColor}40`, color: '#E8F4F8' },
    });
  }, [theme.primaryColor]);

  async function handleSync() {
    setSyncing(true);
    await new Promise(r => setTimeout(r, 1400));
    setSyncing(false);
    toast.success('Synced with start.gg', {
      style: { background: '#0A1428', border: `1px solid ${theme.primaryColor}40`, color: '#E8F4F8' },
    });
  }

  const totalPlayers = players.length;
  const totalCheckedIn = players.filter(p => p.checkedIn).length;
  const totalActive = matches.filter(m => m.state === 'in_progress' || m.state === 'called').length;
  const totalStationsActive = stations.filter(s => s.active && s.matchId).length;

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#050A14', color: '#E8F4F8', fontFamily: 'Inter, sans-serif' }}>
      {/* Top bar */}
      <header className="border-b flex items-center justify-between px-6 py-3 shrink-0" style={{ background: '#080E1C', borderColor: 'rgba(0,229,255,0.08)' }}>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #00E5FF, #FF006E)', boxShadow: '0 0 12px rgba(0,229,255,0.4)' }}>
              <Zap size={14} color="#050A14" />
            </div>
            <div>
              <div className="text-sm tracking-wider" style={{ fontFamily: 'Rajdhani, sans-serif', fontWeight: 700 }}>FGC TOURNAMENT HUB</div>
              <div className="text-xs opacity-40" style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9 }}>powered by start.gg</div>
            </div>
          </div>
          <div className="w-px h-8 opacity-20" style={{ background: '#00E5FF' }} />
          <div>
            <div className="text-sm tracking-wider" style={{ fontFamily: 'Rajdhani, sans-serif', fontWeight: 700 }}>{TOURNAMENT.name}</div>
            <div className="flex items-center gap-1.5">
              <MapPin size={9} className="opacity-40" />
              <span className="text-xs opacity-40" style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9 }}>
                {TOURNAMENT.venue} · {TOURNAMENT.location}
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#00FF88' }} />
            <span className="text-xs" style={{ fontFamily: 'JetBrains Mono, monospace', color: '#00FF88' }}>LIVE</span>
          </div>
          <a href={TOURNAMENT.sourceUrl} target="_blank" rel="noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs tracking-wider hover:opacity-80 transition-opacity"
            style={{ background: 'rgba(0,229,255,0.08)', border: '1px solid rgba(0,229,255,0.2)', color: '#00E5FF', fontFamily: 'JetBrains Mono, monospace' }}>
            <Globe size={11} />start.gg<ExternalLink size={9} />
          </a>
          <button onClick={handleSync} disabled={syncing}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs tracking-wider hover:opacity-80 transition-opacity disabled:opacity-50"
            style={{ background: 'rgba(0,229,255,0.08)', border: '1px solid rgba(0,229,255,0.2)', color: '#00E5FF', fontFamily: 'JetBrains Mono, monospace' }}>
            <RefreshCw size={11} className={syncing ? 'animate-spin' : ''} />
            {syncing ? 'SYNCING...' : 'SYNC'}
          </button>
        </div>
      </header>

      {/* Game tabs */}
      <div className="flex items-center border-b shrink-0" style={{ background: '#080E1C', borderColor: 'rgba(0,229,255,0.06)' }}>
        {GAME_ORDER.map(gameId => {
          const gt = GAME_THEMES[gameId];
          const isActive = activeGame === gameId;
          const liveCount = matches.filter(m => m.gameId === gameId && (m.state === 'in_progress' || m.state === 'called')).length;
          return (
            <button key={gameId} onClick={() => setActiveGame(gameId)}
              className="relative flex items-center gap-2 px-5 py-3 transition-all"
              style={{
                background: isActive ? `${gt.primaryColor}10` : 'transparent',
                borderBottom: isActive ? `2px solid ${gt.primaryColor}` : '2px solid transparent',
              }}>
              <div className="w-2 h-2 rounded-full" style={{ background: gt.primaryColor, boxShadow: isActive ? `0 0 6px ${gt.primaryColor}` : 'none' }} />
              <span className="text-sm tracking-wider whitespace-nowrap" style={{ fontFamily: 'Rajdhani, sans-serif', fontWeight: 700, color: isActive ? gt.primaryColor : '#7A9EC0' }}>
                {gt.displayName}
              </span>
              {liveCount > 0 && (
                <span className="text-xs px-1.5 py-0.5 rounded-full" style={{ background: `${gt.primaryColor}20`, color: gt.primaryColor, fontFamily: 'JetBrains Mono, monospace', fontSize: 9 }}>
                  {liveCount} LIVE
                </span>
              )}
            </button>
          );
        })}
        <div className="flex-1" />
        <div className="flex items-center gap-5 px-5 opacity-50">
          {[
            { label: 'PLAYERS', value: totalPlayers },
            { label: 'CHECKED IN', value: totalCheckedIn },
            { label: 'LIVE', value: totalActive },
            { label: 'BUSY', value: totalStationsActive },
          ].map(s => (
            <div key={s.label} className="text-right">
              <div className="text-xs leading-none mb-0.5" style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 8, opacity: 0.6 }}>{s.label}</div>
              <div className="text-sm tabular-nums" style={{ fontFamily: 'Rajdhani, sans-serif', fontWeight: 700 }}>{s.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Game banner */}
      <AnimatePresence mode="wait">
        <motion.div key={activeGame} initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
          <GameBanner theme={theme} entrantCount={gamePlayers.length} checkedInCount={checkedInCount} activeMatchCount={activeMatches.length} />
        </motion.div>
      </AnimatePresence>

      {/* Nav tabs */}
      <div className="flex items-center border-b shrink-0 px-4" style={{ background: '#080E1C', borderColor: `${theme.primaryColor}12` }}>
        {TABS.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className="flex items-center gap-1.5 px-4 py-2.5 transition-all text-xs tracking-widest"
              style={{
                fontFamily: 'JetBrains Mono, monospace',
                color: isActive ? theme.primaryColor : '#7A9EC0',
                borderBottom: isActive ? `2px solid ${theme.primaryColor}` : '2px solid transparent',
                background: isActive ? `${theme.primaryColor}06` : 'transparent',
              }}>
              <Icon size={12} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Main content */}
      <main className="flex-1 overflow-auto p-5">
        <AnimatePresence mode="wait">
          <motion.div key={`${activeGame}-${activeTab}`} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}>
            {activeTab === 'overview' && (
              <OverviewTab players={players} matches={matches} stations={stations} onCallMatch={handleCallMatch} />
            )}
            {activeTab === 'bracket' && (
              <div>
                <SectionHeader title="TOURNAMENT BRACKET" subtitle={`${theme.displayName} · Single Elimination`} theme={theme} />
                <BracketView
                  matches={gameMatches}
                  players={gamePlayers}
                  theme={theme}
                  onCallMatch={m => {
                    const availStation = stations.find(s => s.active && !s.matchId);
                    if (availStation) handleCallMatch(m, availStation.id);
                    else toast.error('No available stations', { style: { background: '#0A1428', color: '#E8F4F8' } });
                  }}
                />
              </div>
            )}
            {activeTab === 'checkin' && (
              <div>
                <SectionHeader title="PARTICIPANT CHECK-IN" subtitle={`${checkedInCount} of ${gamePlayers.length} checked in`} theme={theme} />
                <CheckInPanel players={gamePlayers} theme={theme} onCheckIn={handleCheckIn} />
              </div>
            )}
            {activeTab === 'stations' && (
              <div>
                <SectionHeader title="STATION MANAGEMENT" subtitle={`${stations.filter(s => s.active && s.matchId).length} / ${stations.filter(s => s.active).length} stations occupied`} theme={theme} />
                <StationsPanel
                  stations={stations}
                  matches={matches}
                  players={players}
                  theme={theme}
                  onAssignMatch={handleAssignMatch}
                  onCallMatch={(m, sid) => handleCallMatch(m, sid)}
                  onClearStation={handleClearStation}
                />
              </div>
            )}
            {activeTab === 'sms' && (
              <div>
                <SectionHeader title="SMS NOTIFICATIONS" subtitle="Send match calls & announcements via Twilio" theme={theme} />
                <SMSPanel
                  players={gamePlayers}
                  matches={gameMatches}
                  theme={theme}
                  smsLogs={smsLogs.filter(l => gamePlayers.some(p => p.id === l.playerId))}
                  onSendSMS={handleSendSMS}
                />
              </div>
            )}
            {activeTab === 'mobile' && (
              <div>
                <SectionHeader title="MOBILE COMPANION" subtitle="Preview the player-facing companion app" theme={theme} />
                <MobileCompanion players={players} matches={matches} theme={theme} />
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Announcement overlay */}
      <AnnouncementOverlay
        match={announcement}
        players={players}
        theme={announcement ? GAME_THEMES[announcement.gameId] : theme}
        onDismiss={() => {
          if (announcement) {
            setMatches(prev => prev.map(m => m.id === announcement.id ? { ...m, state: 'in_progress' } : m));
          }
          setAnnouncement(null);
        }}
      />

      <Toaster position="bottom-right" />
    </div>
  );
}

// ── Overview Tab ──

function OverviewTab({
  players, matches, stations, onCallMatch
}: {
  players: Player[];
  matches: BracketMatch[];
  stations: Station[];
  onCallMatch: (match: BracketMatch, stationId: number) => void;
}) {
  const playerMap = Object.fromEntries(players.map(p => [p.id, p]));
  const activeMatches = matches.filter(m => m.state === 'in_progress' || m.state === 'called');
  const pendingReadyMatches = matches.filter(m => m.state === 'pending' && m.player1Id && m.player2Id);
  const notCheckedIn = players.filter(p => !p.checkedIn);

  return (
    <div className="grid gap-4" style={{ gridTemplateColumns: '1fr 1fr' }}>
      {/* Live matches full width */}
      <div className="col-span-2 rounded overflow-hidden" style={{ background: '#0A1428', border: `1px solid rgba(0,229,255,0.12)` }}>
        <div className="px-5 py-3 border-b flex items-center gap-2" style={{ borderColor: 'rgba(0,229,255,0.08)', background: '#080E1C' }}>
          <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#00FF88' }} />
          <span className="text-xs tracking-widest" style={{ fontFamily: 'JetBrains Mono, monospace', color: '#00FF88' }}>LIVE MATCHES</span>
          <span className="ml-auto text-xs opacity-40" style={{ fontFamily: 'JetBrains Mono, monospace' }}>{activeMatches.length} active</span>
        </div>
        {activeMatches.length === 0 ? (
          <div className="py-6 text-center text-sm opacity-30" style={{ fontFamily: 'JetBrains Mono, monospace' }}>No live matches right now</div>
        ) : (
          activeMatches.map(m => {
            const gt = GAME_THEMES[m.gameId];
            const p1 = m.player1Id ? playerMap[m.player1Id] : null;
            const p2 = m.player2Id ? playerMap[m.player2Id] : null;
            return (
              <div key={m.id} className="flex items-center gap-4 px-5 py-3" style={{ borderBottom: '1px solid rgba(122,158,192,0.06)' }}>
                <span className="text-xs px-2 py-0.5 rounded" style={{ background: `${gt.primaryColor}15`, color: gt.primaryColor, fontFamily: 'JetBrains Mono, monospace', fontSize: 9 }}>{gt.shortName}</span>
                <span className="text-sm" style={{ fontFamily: 'Rajdhani, sans-serif', fontWeight: 700 }}>
                  {p1?.tag ?? 'TBD'} <span style={{ color: gt.primaryColor }}>vs</span> {p2?.tag ?? 'TBD'}
                </span>
                <span className="text-xs opacity-40" style={{ fontFamily: 'JetBrains Mono, monospace' }}>{m.roundName}</span>
                <div className="ml-auto flex items-center gap-4">
                  {m.stationId && (
                    <span className="flex items-center gap-1 text-xs" style={{ fontFamily: 'JetBrains Mono, monospace', color: gt.primaryColor }}>
                      <Monitor size={11} /> STN {m.stationId}
                    </span>
                  )}
                  <span className="text-xs tabular-nums" style={{ fontFamily: 'JetBrains Mono, monospace', color: '#FFD600' }}>
                    {m.player1Score} – {m.player2Score}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Ready to call */}
      <div className="rounded overflow-hidden" style={{ background: '#0A1428', border: '1px solid rgba(122,158,192,0.12)' }}>
        <div className="px-5 py-3 border-b flex items-center gap-2" style={{ borderColor: 'rgba(122,158,192,0.08)', background: '#080E1C' }}>
          <span className="text-xs tracking-widest" style={{ fontFamily: 'JetBrains Mono, monospace', color: '#FFD600' }}>READY TO CALL</span>
          <span className="ml-auto text-xs opacity-40" style={{ fontFamily: 'JetBrains Mono, monospace' }}>{pendingReadyMatches.length}</span>
        </div>
        <div className="overflow-y-auto" style={{ maxHeight: 300 }}>
          {pendingReadyMatches.slice(0, 10).map(m => {
            const gt = GAME_THEMES[m.gameId];
            const p1 = m.player1Id ? playerMap[m.player1Id] : null;
            const p2 = m.player2Id ? playerMap[m.player2Id] : null;
            const availStation = stations.find(s => s.active && !s.matchId && (!s.gameId || s.gameId === m.gameId));
            return (
              <div key={m.id} className="flex items-center gap-3 px-5 py-2.5 hover:bg-white/5 transition-colors" style={{ borderBottom: '1px solid rgba(122,158,192,0.05)' }}>
                <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: gt.primaryColor }} />
                <div className="flex-1 min-w-0">
                  <div className="text-xs truncate" style={{ fontFamily: 'Rajdhani, sans-serif', fontWeight: 700, color: '#E8F4F8' }}>
                    {p1?.tag ?? 'TBD'} vs {p2?.tag ?? 'TBD'}
                  </div>
                  <div className="text-xs opacity-40" style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9 }}>
                    {gt.shortName} · {m.roundName}
                  </div>
                </div>
                {availStation && (
                  <button
                    onClick={() => onCallMatch(m, availStation.id)}
                    className="shrink-0 px-2.5 py-1 rounded text-xs tracking-wider hover:opacity-80 transition-opacity"
                    style={{ background: `${gt.primaryColor}15`, border: `1px solid ${gt.primaryColor}30`, color: gt.primaryColor, fontFamily: 'JetBrains Mono, monospace', fontSize: 10 }}
                  >
                    CALL
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Not checked in */}
      <div className="rounded overflow-hidden" style={{ background: '#0A1428', border: '1px solid rgba(255,23,68,0.15)' }}>
        <div className="px-5 py-3 border-b flex items-center gap-2" style={{ borderColor: 'rgba(255,23,68,0.1)', background: '#080E1C' }}>
          <span className="text-xs tracking-widest" style={{ fontFamily: 'JetBrains Mono, monospace', color: '#FF1744' }}>NOT CHECKED IN</span>
          <span className="ml-auto text-xs opacity-40" style={{ fontFamily: 'JetBrains Mono, monospace' }}>{notCheckedIn.length}</span>
        </div>
        <div className="overflow-y-auto" style={{ maxHeight: 300 }}>
          {notCheckedIn.length === 0 ? (
            <div className="py-6 text-center text-xs" style={{ fontFamily: 'JetBrains Mono, monospace', color: '#00FF88' }}>✓ All players checked in!</div>
          ) : (
            notCheckedIn.map(p => {
              const gt = GAME_THEMES[p.gameId];
              return (
                <div key={p.id} className="flex items-center gap-3 px-5 py-2.5" style={{ borderBottom: '1px solid rgba(122,158,192,0.05)' }}>
                  <span className="text-sm">{p.countryFlag}</span>
                  <div className="flex-1">
                    <div className="text-xs" style={{ fontFamily: 'Rajdhani, sans-serif', fontWeight: 700, color: '#E8F4F8' }}>{p.tag}</div>
                    <div className="text-xs opacity-40" style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9 }}>{gt.shortName} · #{p.seed}</div>
                  </div>
                  <span className="text-xs opacity-30 tabular-nums" style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10 }}>{p.phone}</span>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

function SectionHeader({ title, subtitle, theme }: { title: string; subtitle?: string; theme: GameTheme }) {
  return (
    <div className="mb-5">
      <div className="text-xl tracking-wider" style={{ fontFamily: 'Rajdhani, sans-serif', fontWeight: 700, color: theme.primaryColor }}>
        {title}
      </div>
      {subtitle && (
        <div className="text-xs opacity-40 mt-0.5" style={{ fontFamily: 'JetBrains Mono, monospace' }}>{subtitle}</div>
      )}
    </div>
  );
}
